import os
import img2pdf
print(os.getcwd())
a=input('Enter image path (just copy and paste):-')

c=input('image name wanna keep:-')

path=input('paste the path where you wanna save it:-')
os.chdir(path)

with open(f'{c}.pdf','wb') as f:
    f.write(img2pdf.convert(a))
