import os
import img2pdf
print(os.getcwd())
a=input('Enter image path (just copy and paste):-')

c=input('image name wanna keep:-')

with open(f'{c}.pdf','wb') as f:
    f.write(img2pdf.convert(a))
