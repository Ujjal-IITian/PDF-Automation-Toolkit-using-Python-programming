import os
import pypdf
import win32com.client

speaker=win32com.client.Dispatch('SAPI.SpVoice')    #initializing speaker

print(os.getcwd())
a=input('Enter file path (just copy and paste):-')

reader=pypdf.PdfReader(a,'rb')

starting_page=int(input('Enter the page number from where to start:-'))
Ending_page=int(input('Enter upto where you wanna hear:-'))

range_=[starting_page,Ending_page]
for i in range(range_[0]-1,range_[1]):
            which_pages=reader.pages[i]
            #print('page:',i+1)
            text=which_pages.extract_text()
            #print(text)
            speaker.Speak(text)

