import os
import pypdf
print(os.getcwd())
a=input('Enter pdf file path (just copy and paste):-')
reader=pypdf.PdfReader(f'{a}','rb')
no_of_pages=len(reader.pages)
print('Total number of pages:',no_of_pages)
b=int(input('which page text you wanna see, enter the page number:-'))
which_page=reader.pages[b-1]  #page2
text=which_page.extract_text()

print(text)
