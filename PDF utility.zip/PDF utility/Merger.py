import os
import pypdf
print(os.getcwd())
a=[]
while (b:=input('enter pdf file path:-')).lower()!='stop':  #copy and paste inside code.
    a.append(b)
    print('Merging PDFs:',a)

    writer=pypdf.PdfWriter()    #writer variable will write a new pdf for us.

    for i in a: #it will add all pages from all pdfs inside writer variable.
     reader=pypdf.PdfReader(f'{i}','rb')  #pdf reader
     for j in range(len(reader.pages)):
         writer.add_page(reader.pages[j])   #adding all pages one by one to the writer variable.
    c=input('file name for merged pdf:-')
    path=input('paste the path where you wanna save the file:-')
    os.chdir(path)
    with open(f'{c}.pdf','wb') as f:
        writer.write(f)         #writer will write its content inside f.
