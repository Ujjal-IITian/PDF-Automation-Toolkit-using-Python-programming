import os
import pypdf
print(os.getcwd())
a=input('Enter file name:-')
reader=pypdf.PdfReader(f'{a}.pdf')  #pdf reader
#no_of_pages=len(reader.pages)

b=int(input('which page text you wanna see, enter the page number:-'))
which_page=reader.pages[b-1]  #page2

#text=which_page.extract_text()
#print(no_of_pages)
#print(text)

writer=pypdf.PdfWriter()    #writer variable will write a new pdf for us.

#which_page.rotateClockwise(90)  #rorating in 90 degree (only 90 multiples)

writer.add_page(which_page) #writer will add the modified which_page new variable.

path=input('paste the path where you wanna save the file:-')
os.chdir(path)

with open('rotated.pdf','wb') as f:
    writer.write(f)

