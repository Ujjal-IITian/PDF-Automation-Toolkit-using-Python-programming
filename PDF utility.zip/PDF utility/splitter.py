import os
import pypdf
print(os.getcwd())
a=input('Enter file path (just copy and paste):-')
reader=pypdf.PdfReader(f'{a}','rb')

spliting_range_low=int(input('splited first page number:-'))
spliting_range_high=int(input('splited last page number:-'))

range_=[spliting_range_low,spliting_range_high]
print(range_)

writer=pypdf.PdfWriter()
c=input('splited file name wanna keep:-')

for i in range(range_[0]-1,range_[1]):

    writer.add_page(reader.pages[i])
    
    with open(f'{c}.pdf','wb') as f:
        writer.write(f)

