import os
import pypdf
print(os.getcwd())
a=input('Enter pdf file path (just copy and paste):-')
reader=pypdf.PdfReader(f'{a}','rb')

password=input('Enter a password you wanna keep:-')

writer=pypdf.PdfWriter()
c=input('Encrypted file name wanna keep:-')

for i in range(len(reader.pages)):
    writer.add_page(reader.pages[i])
writer.encrypt(f'{password}',None,True)

#writer.encrypt(user_pwd=f'{password}',owner_pwd=None,use_128bit=True)
path=input('paste the path where you wanna save it:-')
os.chdir(path)
with open(f'{c}.pdf','wb') as f:
    writer.write(f)

#Final file will be saved in the same location of the script path.
    
